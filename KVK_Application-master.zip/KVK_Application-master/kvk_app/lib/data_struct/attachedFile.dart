class AttachedFile {
  String fileId;
  String name;
  String filetype;
  String fileURL;
  String fileSize;
  bool local = false;
}
