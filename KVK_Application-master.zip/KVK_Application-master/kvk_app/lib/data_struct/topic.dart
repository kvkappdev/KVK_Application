class Topic {
  String id = "-1";
  String engName = "Uncategorised";
  String marName ="Uncategorised M";
}
