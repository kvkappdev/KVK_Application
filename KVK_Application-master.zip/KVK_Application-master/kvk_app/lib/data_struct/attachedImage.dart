class AttachedImage {
  String imgId;
  String path;
  bool local = false;
  String size;
}
